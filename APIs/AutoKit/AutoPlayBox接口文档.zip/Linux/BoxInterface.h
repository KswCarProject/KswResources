/*
 * Copyright(c) 2014-2017 DongGuan HeWei Communication Technologies Co. Ltd.
 * file    BoxInterface.h
 * brief   
 * detail  
 *
 * author  Shi Kai
 * version 1.0.0
 * date    112月17
 *
 * warning 
 *
 * history \arg 1.0.0, 112月17, Shi Kai, Create the file.
 */

#ifndef __BOXINTERFACE_H__
#define __BOXINTERFACE_H__


//接口消息定义
struct CBox_Message {  
public:
	enum { //video_type, 视频压缩类型，目前仅支持H264
		COMPRESS_METHORD_LZO_RGB565 = 1,
		COMPRESS_METHORD_LZO_RGBA8888 = 2,
		COMPRESS_METHORD_JPEG = 3,
		COMPRESS_METHORD_LZO_YUV= 4,
		COMPRESS_METHORD_H264= 5,
	};
	struct stImageBuffer {
		int cx;
		int cy;
		int video_type;
		int video_size;
		void *GetBuf() { return (void*)(this+1); }       //CBox_Message 未析构之前，永远不会变化
	};


	enum { //decode_type, 音频解码类型
		AUDIO_AAC_ELD = 1,      //44100 16bit 2channel, use AAC_ELD compress
		AUDIO_HIGH_PCM = 2, //44100 16bit 2 channel
		AUDIO_LOW_PCM = 3, //8000 16bit 1 channel
		AUDIO_HIGHER_PCM = 4, //48000 16bit 2 channel
		AUDIO_16K_PCM = 5, //16000 16bit 1 channel
		AUDIO_24K_PCM = 6, //24000 16bit 1 channel

	};       
	enum  { //audio_type, 音频种类
		AUDIO_MAIN = 1, //主音频，媒体音乐、语音指令等在这个通道
		AUDIO_ALTERNATE = 2,  //需要混音的音频，导航音、按键音等在这个通道
		AUDIO_INPUT = 3, //录音音频
	};   

	enum {
		AUDIO_OUTPUT_START = 1,
		AUDIO_OUTPUT_STOP = 2,
		AUDIO_INPUT_CONFIG = 3,
		AUDIO_PHONECALL_START = 4, 
		AUDIO_PHONECALL_STOP = 5, 
		AUDIO_NAVI_START = 6, 
		AUDIO_NAVI_STOP = 7, 
	};

	struct stAudioBuffer {
		int decode_type;
		int audio_type;
		int audio_size;
		float audio_volume;
		void *GetBuf() { return (void*)(this+1); }   
	};
	//static stAudioBuffer *GetAudioBuffer(); 


	enum { //On_Phase，回调参数, 盒子与手机的状态变化消息
		PHASE_READY //盒子准备就绪
		,PHASE_PLUGIN //手机插入
	 	,PHASE_PLUGOUT //手机拔出
		,PHASE_WORKING //连接成功
	};
	enum { //On_Message，回调参数，连接成功后的交互消息
		CARPLAY_WORK_START = 1, //CarPlay 开始工作，需要断开车机与手机的蓝牙连接 
		ANDROIDAUTO_WORK_START = 2, //AndroidAuto 开始工作，需要连接车机与手机的蓝牙 
		CARLIFE_WORK_START = 3, //CarLife 开始工作，需要连接车机与手机的蓝牙 
		IOSMIRROR_WORK_START = 4, //iOS镜像 开始工作，需要断开车机与手机的蓝牙连接
		ANDROIDMIRROR_WORK_START = 5, //Android镜像 开始工作，需要连接车机与手机的蓝牙
		AUTOBOX_WORK_STOP = 10, //结束工作

		RETURN_CAR_UI = 20, //请求返回到车机的UI
		RECORD_START = 21, //请求开始录音，需打开录音器准备录音
		RECORD_STOP = 22, //请求结束录音，需关闭录音器清理资源
		NAVI_REPORT_START = 23, //导航播报开始
		NAVI_REPORT_STOP = 24, //导航播报结束
		CARPLAY_PHONECALL_START = 25, //CarPlay 开始打电话
		CARPLAY_PHONECALL_STOP = 26, //CarPlay 结束打电话

	}; 
	enum { SCREEN_OFF, SCREEN_ON}; //On_Srceen_OnOff，回调参数

	enum { ERR_RECV, ERR_SEND, ERR_UNKNOWN }; //On_Err，回调参数

	enum { //boxSetConfig, iOSWorkMode 参数
		INVAILD_MODE, //仅充电模式，仅需要充电时可以设置该模式
		AIRPLAY_MODE, //该模式已弃用，请不要设置
		CARPLAY_MODE, //CarPlay模式
		IOS_MIRROR_MODE //镜像模式（没有反控功能）
	};
	enum { //boxSetConfig, androidWorkMode 参数
		ANDROID_AUTO_MODE = 1, //AndroidAuto模式，国外使用
		CARLIFE_MODE,	//CarLife模式，国内使用
		ANDROID_MIRROR_MODE //镜像模式
	};

	enum{ //触摸类型, SendTouch的第一个参数
		 PUSH
		,MOVE
		,RELEASE
	};

	enum { //Android镜像按键，SendCommand的参数
		 COMMAND_HOME                       //HOME按键
		,COMMAND_BACK					      //回退按键 
		,COMMAND_INVISIBLE					//set invisible
		,COMMAND_VISIBLE					//set visible
	};

	enum { //SendCarplayCmd的参数, 发送给手机的控制指令
		CarPlay_SiriButtonDown = 5, //Siri按钮按下
		CarPlay_SiriButtonUp = 6, //Siri按钮弹起，请成对发送这俩个命令，间隔在10ms以上
		CarPlay_RequestKeyFrame = 12, //请求I帧，解码中断再次显示需要发送这个命令

		//方向控制
		CarPlay_CtrlButtonLeft = 100, //向左
		CarPlay_CtrlButtonRight = CarPlay_CtrlButtonLeft+1, //向右
		CarPlay_CtrlButtonUp = CarPlay_CtrlButtonLeft+2, //向上
		CarPlay_CtrlButtonDown = CarPlay_CtrlButtonLeft+3, //向下
		CarPlay_CtrlButtonEnter = CarPlay_CtrlButtonLeft+4, //选中按下
		CarPlay_CtrlButtonRelease = CarPlay_CtrlButtonLeft+5, //选中弹起，请成对发送这俩个命令，间隔在10ms以上
		CarPlay_CtrlButtonBack = CarPlay_CtrlButtonLeft+6, //返回
		//音乐控制
		CarPlay_MusicACHome = 200, //回主界面，CarPlay UI 主界面
		CarPlay_MusicPlay = CarPlay_MusicACHome+1, //播放
		CarPlay_MusicPause = CarPlay_MusicACHome+2, //暂停
		CarPlay_MusicPlayOrPause = CarPlay_MusicACHome+3, //播放或暂停
		CarPlay_MusicNext = CarPlay_MusicACHome+4, //下一曲
		CarPlay_MusicPrev = CarPlay_MusicACHome+5, //上一曲
		//电话拨号
		CarPlay_PhoneAnswer = 300, //接听
		CarPlay_PhoneHungUp = CarPlay_PhoneAnswer+1, //挂断
		CarPlay_PhoneKey0 = CarPlay_PhoneAnswer+2,
		CarPlay_PhoneKey1 = CarPlay_PhoneAnswer+3,
		CarPlay_PhoneKey2 = CarPlay_PhoneAnswer+4,
		CarPlay_PhoneKey3 = CarPlay_PhoneAnswer+5,
		CarPlay_PhoneKey4 = CarPlay_PhoneAnswer+6,
		CarPlay_PhoneKey5 = CarPlay_PhoneAnswer+7,
		CarPlay_PhoneKey6 = CarPlay_PhoneAnswer+8,
		CarPlay_PhoneKey7 = CarPlay_PhoneAnswer+9,
		CarPlay_PhoneKey8 = CarPlay_PhoneAnswer+10,
		CarPlay_PhoneKey9 = CarPlay_PhoneAnswer+11,
		CarPlay_PhoneKeyStar = CarPlay_PhoneAnswer+12,
		CarPlay_PhoneKeyPound = CarPlay_PhoneAnswer+13,
	};   

	struct CallBack_t {
		//CallBack Interface Pointer
		void (*_On_Err)(int);
		void (*_On_Phase)(int);
		void (*_On_Srceen_OnOff)(int);
		void (*_On_Image_SizeChanged)(stImageBuffer *);
		void (*_On_Image_Refresh)(stImageBuffer *);
		void (*_On_Audio_Process)(stAudioBuffer *);
		void (*_On_Message)(int);

		CallBack_t() {
			_On_Err = 0;
			_On_Phase = 0;
			_On_Srceen_OnOff = 0;
			_On_Image_SizeChanged = 0;
			_On_Image_Refresh = 0;
			_On_Audio_Process = 0;
			_On_Message= 0;
		}
	};


};

//设置车机适配的参数，初始化之前调用
//w，车机分辨率宽
//h，车机分辨率高
//fps，支持解码的帧率 30 或 60
//iOSWorkMode，iPhone工作模式，
//androidWorkMode，Android工作模式，
void boxSetConfig(int w, int h, int fps, int iOSWorkMode, int androidWorkMode);


//初始化盒子, 程序启动时调用， 传入已实现的一系列回调函数作为参数
int boxInit(CBox_Message::CallBack_t cb);

//关闭盒子，程序退出或出现错误后调用
int boxClose(void);

//发送触摸值 type:触摸类型， _x: 横坐标占比， _y:纵坐标占比。 计算方法：_x = x*10000/总宽度  _y = y * 10000/总高度。
void  SendTouch( int _type, int _x,  int _y);

//Android Mirror 工作模式下，发送Android手机的按键指令
void  SendCommand( int _cmd );

//CarPlay、AndroidAuto、Carlife 工作模式下，发送控制指令
void  SendCarplayCmd( int _cmd );

#endif
