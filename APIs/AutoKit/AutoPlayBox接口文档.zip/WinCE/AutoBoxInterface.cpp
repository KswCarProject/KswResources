#include "StdAfx.h"
#include "AutoBoxInterface.h"

#ifndef SAFECLOSEHANDLE
#define SAFECLOSEHANDLE(h) {if(ISVALIDHANDLE(h)) {::CloseHandle(h); h=INVALID_HANDLE_VALUE;}}
#endif

#ifndef ISVALIDHANDLE
#define ISVALIDHANDLE(h)   ((INVALID_HANDLE_VALUE!=(HANDLE)h) && (0!=h))
#endif

typedef unsigned int U32;

namespace {
	U32 MSG_SETVISABLE = 0;
	U32 MSG_CHANGELANG = 0;
	U32 MSG_SET_WORKMODE = 0;
	U32 MSG_START_STOP_AIRPLAYAUDIO = 0;
	U32 MSG_BACKING_CAR = 0;
	U32 MSG_SET_AUDIO_VOLUME = 0;
	U32 MSG_SEND_CONTROL_CMD = 0;
	U32 MSG_NOTIFY = 0;

	HWND AutoBoxHWND() {  return FindWindow(NULL, L"AutoPlay"); 	}
};

void CAutoBoxInterface::SetVisable( BOOL _Val)
{
	if ( 0 == MSG_SETVISABLE ) {
		MSG_SETVISABLE =  RegisterWindowMessage(_T("_UIGEAR_ASTEP_VISABLE_"));
	}
	if (MSG_SETVISABLE) {
		HWND hWnd = AutoBoxHWND();
		if (IsWindow(hWnd)) {
			::SendMessage(hWnd, MSG_SETVISABLE, _Val?1:0, 0);
		}
	}
}

void CAutoBoxInterface::SetWorkMode( workmode _val )
{
	if ( 0 == MSG_SET_WORKMODE ) {
		MSG_SET_WORKMODE =  RegisterWindowMessage(_T("_UIGEAR_ASTEP_SET_WORK_MODE_"));
	}
	if (MSG_SET_WORKMODE) {
		HWND hWnd = AutoBoxHWND();
		if (IsWindow(hWnd)) {
			::PostMessage(hWnd, MSG_SET_WORKMODE, (WPARAM)_val, 0);
		}
	}
}

void CAutoBoxInterface::SetLanguage( DWORD _Val)
{
	HANDLE hFile = CreateFile(L"\\temp\\asteplang", GENERIC_READ|GENERIC_WRITE, 0, 0, CREATE_ALWAYS, 0, 0);     
	if (hFile && hFile!=INVALID_HANDLE_VALUE) {
		DWORD dwWrited = 0;
		WriteFile(hFile, &_Val, sizeof(_Val), &dwWrited, 0);
		CloseHandle(hFile);
	}
	if ( 0 == MSG_CHANGELANG ) {
		MSG_CHANGELANG =  RegisterWindowMessage(_T("_UIGEAR_ASTEP_LANGRUAGE_"));
	}
	if (MSG_CHANGELANG) {
		HWND hWnd = AutoBoxHWND();
		if (IsWindow(hWnd)) {
			::PostMessage(hWnd, MSG_CHANGELANG, (WPARAM)_Val, 0);
		}
	}
}


int CAutoBoxInterface::GetNotifyMsgNumber()
{
	if ( 0 == MSG_NOTIFY) {
		MSG_NOTIFY =  RegisterWindowMessage(_T("_UIGEAR_BOX_NOTIFY_"));
	}
	return MSG_NOTIFY;
}

void CAutoBoxInterface::Start_AutoBox_Audio()
{
	if (0 == MSG_START_STOP_AIRPLAYAUDIO) {
		MSG_START_STOP_AIRPLAYAUDIO =  RegisterWindowMessage(_T("_UIGEAR_ASTEP_ONOFF_AA_"));
	}
	if (MSG_START_STOP_AIRPLAYAUDIO) {
		HWND hWnd = AutoBoxHWND();
		if (IsWindow(hWnd)) {
			::PostMessage(hWnd, MSG_START_STOP_AIRPLAYAUDIO, (WPARAM)1, 0);
		}
	}
}

void CAutoBoxInterface::Stop_AutoBox_Audio()
{
	if (0 == MSG_START_STOP_AIRPLAYAUDIO) {
		MSG_START_STOP_AIRPLAYAUDIO =  RegisterWindowMessage(_T("_UIGEAR_ASTEP_ONOFF_AA_"));
	}
	if (MSG_START_STOP_AIRPLAYAUDIO) {
		HWND hWnd = AutoBoxHWND();
		if (IsWindow(hWnd)) {
			::PostMessage(hWnd, MSG_START_STOP_AIRPLAYAUDIO, (WPARAM)0, 0);
		}
	}
}

void CAutoBoxInterface::Set_AutoBox_AudioVolume(int volume)
{
	if (0 == MSG_SET_AUDIO_VOLUME) {
		MSG_SET_AUDIO_VOLUME =  RegisterWindowMessage(_T("_UIGEAR_ASTEP_SET_VOLUME_AA_"));
	}
	if (MSG_SET_AUDIO_VOLUME) {
		HWND hWnd = AutoBoxHWND();
		if (IsWindow(hWnd)) {
			::PostMessage(hWnd, MSG_SET_AUDIO_VOLUME, (WPARAM)volume, 0);
		}
	}
}

void CAutoBoxInterface::SendControlCmd( ctrlcmd _cmd )
{
	if (0 == MSG_SEND_CONTROL_CMD) {
		MSG_SEND_CONTROL_CMD =  RegisterWindowMessage(_T("_UIGEAR_ASTEP_SEND_CTRL_CMD_AA_"));
	}
	if (MSG_SEND_CONTROL_CMD) {
		HWND hWnd = AutoBoxHWND();
		if (IsWindow(hWnd)) {
			::PostMessage(hWnd, MSG_SEND_CONTROL_CMD, (WPARAM)_cmd, 0);
		}
	}

}

void CAutoBoxInterface::On_BackingCar( BOOL _Val )
{
	if (0 == MSG_BACKING_CAR) {
		MSG_BACKING_CAR =  RegisterWindowMessage(_T("_UIGEAR_ASTEP_BACKINGCAR_AA_"));
	}
	if (MSG_BACKING_CAR) {
		HWND hWnd = AutoBoxHWND();
		if (IsWindow(hWnd)) {
			::PostMessage(hWnd, MSG_BACKING_CAR, (WPARAM)_Val, 0);
		}
	}
}
